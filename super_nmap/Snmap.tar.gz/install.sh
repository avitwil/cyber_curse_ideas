#!/bin/bash
echo "Installing package..."
sudo dpkg -i Snmap.deb
