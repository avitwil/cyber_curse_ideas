#!/bin/bash
echo "Installing package..."
sudo dpkg -i py2deb.deb
